extends Menu
class_name ControlsMenu

@export var path_follow_2D : PathFollow2D

func _on_close_button_pressed():
	open_menu()
	controls_open = false
	close_controls()

func _on_restart_level_pressed():
	GameManager.load_area(GameManager.current_area)

func _on_open_controls_pressed():
	close_menu()
	controls_open = true
	open_controls()
