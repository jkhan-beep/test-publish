extends CharacterBody2D
class_name PlayerController

@export var speed = 10.0
@export var jump_power = 10.0
@export var camera : Camera2D
var running = false
var speed_multiplier = 30.0
var jump_multiplier = -30.0
var direction = 0
@export var in_water = false
#const SPEED = 300.0
#const JUMP_VELOCITY = -400.0

# Get the gravity from the project settings to be synced with RigidBody nodes.
var gravity = ProjectSettings.get_setting("physics/2d/default_gravity")

func _input(event):
	# Handle jump.
	if event.is_action_pressed("jump") and is_on_floor() or event.is_action_pressed("jump") and in_water:
		velocity.y = jump_power * jump_multiplier
	# Handle jump down
	if event.is_action_pressed("move_down"):
		set_collision_mask_value(10, false)
	else:
		set_collision_mask_value(10, true)
	if Input.is_action_pressed("run"):
		running = true
	else:
		running = false

func _physics_process(delta):
	# Add the gravity.
	if not is_on_floor():
		if in_water == true:
			velocity.y += (gravity * delta)/2
		else:
			velocity.y += gravity * delta
	if in_water == true and running == false:
		speed_multiplier = 15.0
	elif in_water == false and running == false or in_water == true and running == true:
		speed_multiplier = 30.0
	elif in_water == false and running == true:
		speed_multiplier = 45.0
	if in_water == true:
		jump_multiplier = -15.0
	else:
		jump_multiplier = -30.0

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	direction = Input.get_axis("move_left", "move_right")
	if direction:
		velocity.x = direction * speed * speed_multiplier
	else:           
		velocity.x = move_toward(velocity.x, 0, speed * speed_multiplier)

	move_and_slide()

func teleport_to_location(new_location):
	camera.position_smoothing_enabled = false
	position = new_location
	await get_tree().physics_frame
	camera.position_smoothing_enabled = true

func set_in_water(value):
	in_water = value
