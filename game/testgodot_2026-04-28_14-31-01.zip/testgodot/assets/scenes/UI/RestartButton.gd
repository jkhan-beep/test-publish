extends Button

func _on_restart_button_pressed():
	GameManager.load_area(1)
