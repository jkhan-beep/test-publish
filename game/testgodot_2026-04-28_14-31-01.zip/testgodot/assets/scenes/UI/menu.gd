extends Path2D
class_name Menu

@export var path_time = 1.0
@export var looping = false
@export var ease : Tween.EaseType
@export var transition : Tween.TransitionType
@export var settings_path_2D : Path2D
@export var controls_path_2D : Path2D
@export var main_menu_path_follow_2D : PathFollow2D
@export var settings_path_follow_2D : PathFollow2D
@export var controls_path_follow_2D : PathFollow2D
var generic_controller_texture = preload("res://assets/sprites/controls/generic.png")
var keyboard_controller_texture = preload("res://assets/sprites/controls/keyboard.png")
var xbox_controller_texture = preload("res://assets/sprites/controls/xbox.png")
var ps_controller_texture = preload("res://assets/sprites/controls/ps.png")
var switch_controller_texture = preload("res://assets/sprites/controls/switch.png")
var menu_open = false
var settings_open = false
var controls_open = false
var controller = Input.get_joy_name(0)
var controllertexture = generic_controller_texture

func set_controller_texture():
	for i in get_tree().get_nodes_in_group("controller_texture"):
		i.texture = GameManager.controllertexture

func _input(event):
	# Handle jump.
	if event.is_action_pressed("menu"):
		if controls_open == true:
			controls_open = false
			close_controls()
		if settings_open == true:
			settings_open = false
			close_settings()
		if menu_open == false:
			menu_open = true
			open_menu()
		elif menu_open == true:
			menu_open = false
			close_menu()

func _on_close_button_pressed():
	menu_open = false
	close_menu()

func _on_close_controls_pressed():
	open_menu()
	controls_open = false
	close_controls()

func _on_restart_level_pressed():
	var current_level = GameManager.current_area
	GameManager.load_area(0)
	GameManager.load_area(current_level)
	GameManager.reset_energy_cells()

func _on_open_controls_pressed():
	close_menu()
	controls_open = true
	open_controls()

func open_menu():
	var tween = get_tree().create_tween().set_loops()
	tween.tween_property(main_menu_path_follow_2D, "progress_ratio", 1.0, path_time).set_ease(ease).set_trans(transition)
func close_menu():
	var tween = get_tree().create_tween().set_loops()
	tween.tween_property(main_menu_path_follow_2D, "progress_ratio", 0.0, path_time).set_ease(ease).set_trans(transition)

func open_controls():
	var tween = controls_path_2D.get_tree().create_tween().set_loops()
	tween.tween_property(controls_path_follow_2D, "progress_ratio", 1.0, path_time).set_ease(ease).set_trans(transition)
func close_controls():
	var tween = controls_path_2D.get_tree().create_tween().set_loops()
	tween.tween_property(controls_path_follow_2D, "progress_ratio", 0.0, path_time).set_ease(ease).set_trans(transition)

func open_settings():
	var tween = settings_path_2D.get_tree().create_tween().set_loops()
	tween.tween_property(settings_path_follow_2D, "progress_ratio", 1.0, path_time).set_ease(ease).set_trans(transition)
func close_settings():
	var tween = settings_path_2D.get_tree().create_tween().set_loops()
	tween.tween_property(settings_path_follow_2D, "progress_ratio", 0.0, path_time).set_ease(ease).set_trans(transition)

func _on_generic_texture_pressed():
	controllertexture = generic_controller_texture
	set_controller_texture()

func _on_xbox_texture_pressed():
	controllertexture = xbox_controller_texture
	set_controller_texture()

func _on_ps_texture_pressed():
	controllertexture = ps_controller_texture
	set_controller_texture()

func _on_switch_texture_pressed():
	controllertexture = switch_controller_texture
	set_controller_texture()


func _on_open_settings_pressed():
	close_menu()
	settings_open = true
	open_settings()

func _on_close_settings_pressed():
	open_menu()
	settings_open = false
	close_settings()
