extends Path2D
class_name Menu

@export var path_time = 1.0
@export var looping = false
@export var ease : Tween.EaseType
@export var transition : Tween.TransitionType
@export var controls_path_2D : Path2D
@export var main_menu_path_follow_2D : PathFollow2D
@export var controls_path_follow_2D : PathFollow2D
@export var close_button_texture : NinePatchRect
@export var open_controls_texture : NinePatchRect
@export var close_controls_texture : NinePatchRect
@export var restart_level_texture : NinePatchRect
@export var controller_ui_texture : TextureRect
var default_controller_texture = preload("res://assets/sprites/controls_controller_blank.png")
var ps_controller_texture = preload("res://assets/sprites/controls_controller_3.png")
var xbox_controller_texture = preload("res://assets/sprites/controls_controller_2.png")
var switch_controller_texture = preload("res://assets/sprites/controls_controller_1.png")
var menu_open = false
var controls_open = false
var controller = Input.get_joy_name(0)

func _ready():
	Input.joy_connection_changed.connect(_on_controller_changed)
	update_controller_texture()

func _on_controller_changed(device_id: int, connected: bool):
	update_controller_texture()

func update_controller_texture():
	controller = Input.get_joy_name(0)
	if controller.begins_with("PS"):
		controller_ui_texture.texture = ps_controller_texture
	elif controller.contains("Pro Controller") or controller.contains("Joy-Con") or controller.contains("Switch") or controller.contains("Wii U") or controller.contains("Nintendo Wii"):
		controller_ui_texture.texture = switch_controller_texture
	elif controller.contains("Xbox"):
		controller_ui_texture.texture = xbox_controller_texture
	else:
		controller_ui_texture.texture = default_controller_texture

func _input(event):
	# Handle jump.
	if event.is_action_pressed("menu"):
		if controls_open == true:
			controls_open = false
			close_controls()
		if menu_open == false:
			menu_open = true
			open_menu()
		elif menu_open == true:
			menu_open = false
			close_menu()

func _on_close_button_pressed():
	menu_open = false
	close_menu()

func _on_close_controls_pressed():
	open_menu()
	controls_open = false
	close_controls()

func _on_restart_level_pressed():
	var current_level = GameManager.current_area
	GameManager.load_area(0)
	GameManager.load_area(current_level)
	GameManager.reset_energy_cells()

func _on_open_controls_pressed():
	close_menu()
	controls_open = true
	open_controls()

func _on_mouse_entered():
	close_button_texture.region_rect.position.x = 5

func _on_mouse_entered_controls():
	close_controls_texture.region_rect.position.x = 5

func _on_mouse_entered_open_controls():
	open_controls_texture.region_rect.position.x = 5

func _on_mouse_entered_restart():
	restart_level_texture.region_rect.position.x = 5

func _on_mouse_exited():
	close_button_texture.region_rect.position.x = 0

func _on_mouse_exited_controls():
	close_controls_texture.region_rect.position.x = 0

func _on_mouse_exited_open_controls():
	open_controls_texture.region_rect.position.x = 0

func _on_mouse_exited_restart():
	restart_level_texture.region_rect.position.x = 0


func open_menu():
	var tween = get_tree().create_tween().set_loops()
	tween.tween_property(main_menu_path_follow_2D, "progress_ratio", 1.0, path_time).set_ease(ease).set_trans(transition)
func close_menu():
	var tween = get_tree().create_tween().set_loops()
	tween.tween_property(main_menu_path_follow_2D, "progress_ratio", 0.0, path_time).set_ease(ease).set_trans(transition)

func open_controls():
	var tween = controls_path_2D.get_tree().create_tween().set_loops()
	tween.tween_property(controls_path_follow_2D, "progress_ratio", 1.0, path_time).set_ease(ease).set_trans(transition)
func close_controls():
	var tween = controls_path_2D.get_tree().create_tween().set_loops()
	tween.tween_property(controls_path_follow_2D, "progress_ratio", 0.0, path_time).set_ease(ease).set_trans(transition)


func _on_mouse_entered_close_controls():
	close_controls_texture.region_rect.position.x = 5

func _on_mouse_exited_close_controls():
	close_controls_texture.region_rect.position.x = 0
