extends Area2D
class_name AreaExit

@export var sprite : Sprite2D
@export var load_3d : bool = false

var is_open = false

func _ready():
	close()

func open():
	is_open = true
	sprite.region_rect.position.x = 22

func close():
	is_open = false
	sprite.region_rect.position.x = 0

func _on_body_entered(body):
	if is_open && body is PlayerController:
		if load_3d == false:
			GameManager.next_area()
		else:
			GameManager.load_3d_area()
