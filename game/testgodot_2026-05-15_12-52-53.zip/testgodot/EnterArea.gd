extends Area3D
class_name EnterArea

@export var area_number : int

func _ready():
	$Label3D.set_text("Area " + str(area_number))

func _on_body_entered(body):
	if body is LevelSelectPlayerController:
		GameManager.load_2d_area(area_number)
