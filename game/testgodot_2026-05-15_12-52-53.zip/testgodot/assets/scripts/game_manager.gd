extends Node

var starting_area = 5
var current_area = 5
var area_path = "res://assets/scenes/areas/"

var energy_cells = 0
var area_container : Node2D
var area_container3d : Node3D
var player : PlayerController
var player3d : LevelSelectPlayerController
var hud : HUD
var menu : Menu
var restart_button : Button
var focus_ui = false

var controllertexture = load("res://assets/sprites/controls/generic.png")
var level_select = load("res://assets/scenes/level_select.tscn")
var gameplay = load("res://assets/scenes/gameplay.tscn")
func _ready():
	#preload("res://assets/scenes/level_select.tscn")
	hud = get_tree().get_first_node_in_group("hud")
	area_container = get_tree().get_first_node_in_group("area_container")
	area_container3d = get_tree().get_first_node_in_group("area_container3d")
	player = get_tree().get_first_node_in_group("player")
	player3d = get_tree().get_first_node_in_group("player3d")
	load_area(starting_area)
	Engine.max_fps = 60

func next_area():
	load_area(current_area+1)

func load_area(area_number):
	# Checking the new scene path
	var full_path = area_path + "area_" + str(area_number) + ".tscn"
	var scene = load(full_path) as PackedScene
	if !scene:
		return 
	current_area = area_number
	# Remove previous scene
	for child in area_container.get_children():
		child.queue_free()
		await child.tree_exited
	# Setting up the new scene
	var instance = scene.instantiate()
	area_container.add_child(instance)
	reset_energy_cells()
	#moving the player to the start position of the new scene
	var player_start_position = get_tree().get_first_node_in_group("player_start_position") as Node2D
	player.teleport_to_location(player_start_position.position)

func load_area_from_file(area_file):
	# Checking the new scene path
	var full_path = area_file
	var scene = load(full_path) as PackedScene
	if !scene:
		return 
	current_area = 0
	# Remove previous scene
	for child in area_container.get_children():
		child.queue_free()
		await child.tree_exited
	# Setting up the new scene
	var instance = scene.instantiate()
	area_container.add_child(instance)
	reset_energy_cells()
	#moving the player to the start position of the new scene
	var player_start_position = get_tree().get_first_node_in_group("player_start_position") as Node2D
	player.teleport_to_location(player_start_position.position)

func load_level_select():
	level_select = load("res://assets/scenes/level_select.tscn")
	get_tree().change_scene_to_file("res://assets/scenes/level_select.tscn")
	gameplay.queue_free()
	current_area = -1

func load_2d_area(area_number):
	gameplay = load("res://assets/scenes/gameplay.tscn")
	load_area(area_number)
	get_tree().change_scene_to_file("res://assets/scenes/gameplay.tscn")
	level_select.queue_free()

func add_energy_cell():
	energy_cells += 1
	hud.update_energy_cell_label(energy_cells)
	if energy_cells >= 4:
		var portal = get_tree().get_first_node_in_group("area_exits") as AreaExit
		portal.open()
		hud.portal_opened()
 
func reset_energy_cells():
	energy_cells = 0
	hud.update_energy_cell_label(energy_cells)
	hud.portal_closed()

 
func _on_restart_button_pressed():
	get_tree().reload_current_scene()
