extends Node2D
class_name PlayerAnimator

@export var player_controller : PlayerController
@export var animation_player : AnimationPlayer
@export var sprite : Sprite2D

func _process(delta):
	#flips the character sprite
	if player_controller.direction == 1:
		%PlayerSprite2D.flip_h = false
	elif player_controller.direction == -1:
		%PlayerSprite2D.flip_h = true
	#plays the movement animation
	if abs(player_controller.velocity.x) > 0.0:
		animation_player.play("move")
		if player_controller.running == true:
			if player_controller.in_water == true:
				animation_player.set_speed_scale(1)
			else:
				animation_player.set_speed_scale(2)
		else:
			if player_controller.in_water == true:
				animation_player.set_speed_scale(0.5)
			else:
				animation_player.set_speed_scale(1)
	else:
		animation_player.set_speed_scale(1)
		animation_player.play("idle")
	#plays the jump animation
	if player_controller.velocity.y < 0.0:
		animation_player.play("jump")
	if player_controller.velocity.y > 0.0:
		animation_player.play("fall")
	%PlayerSprite2DMirror.flip_h = %PlayerSprite2D.is_flipped_h()
	%PlayerSprite2DMirror.set_region_rect(%PlayerSprite2D.get_region_rect())
