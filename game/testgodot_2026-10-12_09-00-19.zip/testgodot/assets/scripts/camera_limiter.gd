# An area that the player's camera cannot leave.
#@icon("res://assets/sprites/CameraLimiter.svg")
extends Polygon2D
class_name CameraLimiter

@export var enabled = true

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	if enabled == true:
		GameManager.set_player_camera_limits(polygon.get(3).x,polygon.get(1).x,polygon.get(0).y,polygon.get(2).y)
	else:
		pass

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if enabled == true:
		GameManager.set_player_camera_limits(polygon.get(3).x,polygon.get(1).x,polygon.get(0).y,polygon.get(2).y)
	else:
		pass

func _exit_tree() -> void:
	GameManager.set_player_camera_limits(-10000000,10000000,-10000000,10000000)

func set_enabled(value):
	enabled = value
