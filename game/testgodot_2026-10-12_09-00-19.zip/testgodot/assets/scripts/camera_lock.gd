#@icon("res://assets/sprites/CameraZone.svg")
extends Area2D
class_name CameraZone

@export var target : CameraLimiter
@export var hide_on_exit = false
@export var auto_enable = false
#@export var text : String

func _ready() -> void:
	player = get_tree().get_first_node_in_group("player")
	if auto_enable == false:
		pass
	else:
		target.set_enabled(true)
		#print(text, " on")

var player : PlayerController

func _process(delta: float) -> void:
	if overlaps_body(player):
		target.set_enabled(true)
		#print(text, " on")
	else:
		target.set_enabled(false)
		#print(text, " off")

#func _on_body_entered(body):
#	if body is PlayerController:
#		target.set_enabled(true)
#		print(text, " on")

#func _on_body_exited(body):
#	if hide_on_exit == true and body is PlayerController:
#		target.set_enabled(false)
#		print(text, " off")
