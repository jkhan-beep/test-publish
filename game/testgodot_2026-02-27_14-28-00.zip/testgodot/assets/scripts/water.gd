extends Area2D
class_name water

@export var sprite : Sprite2D

var player : PlayerController

func _ready():
	player = get_tree().get_first_node_in_group("player")

func _on_body_entered(body):
	if body is PlayerController:
		player.set_in_water(true)
func _on_body_exited(body):
	if body is PlayerController:
		player.set_in_water(false)
