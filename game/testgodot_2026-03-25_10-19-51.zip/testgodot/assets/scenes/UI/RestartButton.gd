extends Button

@export var texture : NinePatchRect
@export var label : Label

func _on_restart_button_pressed():
	GameManager.load_area(1)


func _on_mouse_entered():
	texture.region_rect.position.x = 8

func _on_mouse_exited():
	texture.region_rect.position.x = 1
