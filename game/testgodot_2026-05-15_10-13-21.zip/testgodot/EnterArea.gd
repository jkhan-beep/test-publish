extends Area3D
class_name EnterArea

@export var area_number : int

func _ready():
	$Label3D.set_text("Area " + str(area_number+1))

func _on_body_entered(body):
	if body is LevelSelectPlayerController:
		get_tree().change_scene_to_file("res://assets/scenes/gameplay.tscn")
		GameManager.load_area(area_number+1)
