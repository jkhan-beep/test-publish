extends Sprite2D
@export var star_texture : NoiseTexture2D
@export var offset_step : float = 0.001
var offset_counter = 0
# Called when the node enters the scene tree for the first time.
func _ready():
	self.texture = star_texture
	offset_counter = 0

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta):
	offset_counter = offset_counter + offset_step
	self.texture.noise.offset = Vector3(0, 0, offset_counter)
	#object.texture.noise.set_offset(Vector3(offset_counter,0,0))
