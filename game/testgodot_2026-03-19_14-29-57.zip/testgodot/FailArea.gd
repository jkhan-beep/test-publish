extends Area2D
class_name restartarea

@export var sprite : Sprite2D

var player : PlayerController

func _ready():
	player = get_tree().get_first_node_in_group("player")

func _on_body_entered(body):
	if body is PlayerController:
		var current_level = GameManager.current_area
		GameManager.load_area(0)
		GameManager.load_area(current_level)
		GameManager.reset_energy_cells()
