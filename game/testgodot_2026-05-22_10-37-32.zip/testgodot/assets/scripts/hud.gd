extends Control
class_name HUD

@export var gui : Control
@export var energy_cell_label : Label
@export var portal_label : Label

func update_energy_cell_label(number : int):
	energy_cell_label.text = "x " + str(number)

func portal_opened():
	portal_label.text = "Portal open!"

func portal_closed():
	portal_label.text = "Portal closed... Get energy cells!"

func _process(_delta):
	if GameManager.current_area == -1:
		set_hud_visible(false)
	else:
		set_hud_visible(true)
func set_hud_visible(state):
	gui.set_modulate(Color(1,1,1,state))

func _on_switch_texture_mouse_entered():
	pass # Replace with function body.
