extends Area2D
class_name effectarea

@export var canvas_modulate : CanvasModulate = self.Effect.CanvasModulate
@export var polygon_2d : Polygon2D = self.Effect.CanvasLayer.Polygon2D

var player : PlayerController

func _ready():
	player = get_tree().get_first_node_in_group("player")

func _on_body_exited(body):
	if body is PlayerController:
		canvas_modulate.set_visible(false)
func _on_body_entered(body):
	if body is PlayerController:
		canvas_modulate.set_visible(true)
