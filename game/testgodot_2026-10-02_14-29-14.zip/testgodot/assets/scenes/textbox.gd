@icon("TextFile")
extends Window
class_name Textbox

#@export_category("Dialogue")
@export var icon : Texture2D
@export var dialogue_name : String
@export_multiline var text : String
@export var continue_text : String
@export var next_dialogue : Textbox
@export var typing_sound : AudioStream

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass

func _on_visibility_changed() -> void:
	if is_visible() == true:
		GameManager.player_controllable = false
		if dialogue_name:
			%Name.set_text(dialogue_name)
		if text:
			%Text.set_text(text)
		if continue_text:
			%Continue.set_text(continue_text)
		if typing_sound:
			%Audio.set_stream(typing_sound)
		%Text.set_visible_characters(0)
		%Timer.start(0.05)
		if icon:
			%Icon.set_texture(icon)
			%Name._set_position(Vector2(icon._get_width(), 8))
			%Text._set_position(Vector2(icon._get_width(), 16))
		if typing_sound:
			%Audio.play()


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func _on_timer_timeout() -> void:
	if %Text.get_visible_characters() < %Text.get_total_character_count():
		%Text.set_visible_characters(%Text.get_visible_characters()+1)
		if typing_sound:
			%Audio.play()
		%Timer.start(0.05)


func _on_continue_pressed() -> void:
	next_textbox()

func _input(event: InputEvent) -> void:
	if Input.is_action_just_pressed("jump") && %Text.get_visible_characters() == %Text.get_total_character_count():
		next_textbox()
	if Input.is_action_just_pressed("run"):
		%Text.set_visible_characters(%Text.get_total_character_count())
	if Input.is_action_pressed("menu") or Input.is_action_just_pressed("menu"):
		%Text.set_visible_characters(%Text.get_total_character_count())
		next_textbox()

func next_textbox() :
	if next_dialogue:
		next_dialogue.set_visible(true)
	else:
		GameManager.player_controllable = true
	set_visible(false)
