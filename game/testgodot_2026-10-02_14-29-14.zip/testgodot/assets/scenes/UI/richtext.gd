extends RichTextEffect
class_name RichTextTest

# Define the tag name.
var bbcode = "offset"

func _process_custom_fx(char_fx):
	# Get parameters, or use the provided default value if missing.
	var offset = char_fx.env.get("offset",Vector2(0,0))
	return true
