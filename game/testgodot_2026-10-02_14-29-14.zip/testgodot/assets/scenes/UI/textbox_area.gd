extends Area2D

@export var first_textbox : Textbox
@export var interact_to_open : bool
var in_area = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func _on_body_entered(body):
	if body is PlayerController:
		if interact_to_open == false:
			first_textbox.set_visible(true)
		else:
			GameManager.can_jump = false
			self.in_area = true

func _on_body_exited(body: Node2D) -> void:
	if body is PlayerController && interact_to_open == true:
		GameManager.can_jump = true
		self.in_area = false

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("jump") && GameManager.player_controllable == true && interact_to_open == true && self.in_area == true:
		first_textbox.set_visible(true)
