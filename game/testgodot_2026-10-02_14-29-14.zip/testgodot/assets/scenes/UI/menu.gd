extends Path2D
class_name Menu

@export var path_time = 1.0
@export var looping = false
@export var ease : Tween.EaseType
@export var transition : Tween.TransitionType
@export var settings_path_2D : Path2D
@export var controls_path_2D : Path2D
@export var main_menu_path_follow_2D : PathFollow2D
@export var settings_path_follow_2D : PathFollow2D
@export var controls_path_follow_2D : PathFollow2D
@export var restart_lv_button : Button
@export var restart_to_first_lv_button : Button
var generic_controller_texture = preload("res://assets/sprites/controls/generic.png")
var keyboard_controller_texture = preload("res://assets/sprites/controls/keyboard.png")
var xbox_controller_texture = preload("res://assets/sprites/controls/xbox.png")
var ps_controller_texture = preload("res://assets/sprites/controls/ps.png")
var switch_controller_texture = preload("res://assets/sprites/controls/switch.png")
var menu_open = false
var settings_open = false
var controls_open = false
var controller = Input.get_joy_name(0)
var controllertexture = generic_controller_texture
var scene_tree : SceneTree
var player : PlayerController
var resource : Resource

func set_controller_texture():
	for i in get_tree().get_nodes_in_group("controller_texture"):
		i.texture = GameManager.controllertexture
func _input(event):
	# Handle jump.
	if event.is_action_pressed("menu") && GameManager.textbox == false:
		if controls_open == true:
			controls_open = false
			close_controls()
			GameManager.player_controllable = true
			GameManager.player_physics = true
		if settings_open == true:
			settings_open = false
			close_settings()
			GameManager.player_controllable = true
			GameManager.player_physics = true
		if menu_open == false:
			menu_open = true
			open_menu()
			GameManager.player_controllable = false
			GameManager.player_physics = false
		elif menu_open == true:
			menu_open = false
			close_menu()
			GameManager.player_controllable = true
			GameManager.player_physics = true

func _on_close_button_pressed():
	menu_open = false
	close_menu()

func _on_close_controls_pressed():
	open_menu()
	controls_open = false
	close_controls()

func _on_restart_level_pressed():
	var current_level = GameManager.current_area_path
	GameManager.load_area(0)
	GameManager.load_area_from_file(current_level)
	GameManager.reset_energy_cells()

func _on_open_controls_pressed():
	close_menu()
	controls_open = true
	open_controls()

func open_menu():
	var tween = get_tree().create_tween().set_loops()
	tween.tween_property(main_menu_path_follow_2D, "progress_ratio", 1.0, path_time).set_ease(ease).set_trans(transition)
	self.PathFollow2D.Main.CloseButton.grab_focus()
func close_menu():
	var tween = get_tree().create_tween().set_loops()
	tween.tween_property(main_menu_path_follow_2D, "progress_ratio", 0.0, path_time).set_ease(ease).set_trans(transition)
	self.ClosedMenu.grab_focus()

func open_controls():
	var tween = controls_path_2D.get_tree().create_tween().set_loops()
	tween.tween_property(controls_path_follow_2D, "progress_ratio", 1.0, path_time).set_ease(ease).set_trans(transition)
	self.Path2DControls.PathFollow2D.Controls.CloseControls.grab_focus()
func close_controls():
	var tween = controls_path_2D.get_tree().create_tween().set_loops()
	tween.tween_property(controls_path_follow_2D, "progress_ratio", 0.0, path_time).set_ease(ease).set_trans(transition)

func open_settings():
	var tween = settings_path_2D.get_tree().create_tween().set_loops()
	tween.tween_property(settings_path_follow_2D, "progress_ratio", 1.0, path_time).set_ease(ease).set_trans(transition)
func close_settings():
	var tween = settings_path_2D.get_tree().create_tween().set_loops()
	tween.tween_property(settings_path_follow_2D, "progress_ratio", 0.0, path_time).set_ease(ease).set_trans(transition)

func _on_generic_texture_pressed():
	controllertexture = generic_controller_texture
	set_controller_texture()

func _on_xbox_texture_pressed():
	controllertexture = xbox_controller_texture
	set_controller_texture()

func _on_ps_texture_pressed():
	controllertexture = ps_controller_texture
	set_controller_texture()

func _on_switch_texture_pressed():
	controllertexture = switch_controller_texture
	set_controller_texture()


func _on_open_settings_pressed():
	close_menu()
	settings_open = true
	open_settings()

func _on_close_settings_pressed():
	open_menu()
	settings_open = false
	close_settings()

func _process(delta):
	if GameManager.current_area == -1:
		restart_lv_button.set_disabled(true)
		restart_to_first_lv_button.set_disabled(true)
	else:
		restart_lv_button.set_disabled(false)
		restart_to_first_lv_button.set_disabled(false)

func set_restart_disabled(state):
	restart_lv_button.set_disabled(state)
	restart_to_first_lv_button.set_disabled(state)
