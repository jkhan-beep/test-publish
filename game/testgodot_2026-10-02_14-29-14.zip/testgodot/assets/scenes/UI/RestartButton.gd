extends Button

func _on_restart_button_pressed():
	#GameManager.load_area(2)
	GameManager.load_area_from_file(load("res://assets/scenes/level_select.tscn"))
