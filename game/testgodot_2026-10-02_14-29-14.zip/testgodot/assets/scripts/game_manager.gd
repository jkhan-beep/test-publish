extends Node

var starting_area = 2
var current_area = 2
var area_path = "res://assets/scenes/areas/"
var current_area_path = "res://assets/scenes/areas/area_2.tscn"

var energy_cells = 0
var area_container : Node2D
var area_container3d : Node3D
var player : PlayerController
var player3d : LevelSelectPlayerController
var hud : HUD
var menu : Menu
var restart_button : Button
var focus_ui = false
var scene_tree : SceneTree
var player_controllable = true
var player_physics = true
var textbox = false
var can_jump = true
var settings = {
	fullscreen = false,
	audio_mute = {
		master = false,
		dialogue = false
	},
	controller = "generic"
}
var audio_bus = load("res://assets/Sounds/default_bus_layout.tres")

var gameplay = load("res://assets/scenes/gameplay.tscn")
func _ready():
	#preload("res://assets/scenes/level_select.tscn")
	hud = get_tree().get_first_node_in_group("hud")
	area_container = get_tree().get_first_node_in_group("area_container")
	area_container3d = get_tree().get_first_node_in_group("area_container3d")
	player = get_tree().get_first_node_in_group("player")
	player3d = get_tree().get_first_node_in_group("player3d")
	load_area(starting_area)
	Engine.max_fps = 60

func next_area():
	load_area(current_area+1)

func load_area(area_number):
	# Checking the new scene path
	var full_path = area_path + "area_" + str(area_number) + ".tscn"
	var scene = load(full_path) as PackedScene
	if !scene:
		return 
	current_area = area_number
	# Remove previous scene
	for child in area_container.get_children():
		child.queue_free()
		await child.tree_exited
	# Setting up the new scene
	var instance = scene.instantiate()
	area_container.add_child(instance)
	reset_energy_cells()
	#moving the player to the start position of the new scene
	var player_start_position = get_tree().get_first_node_in_group("player_start_position") as Node2D
	player.teleport_to_location(player_start_position.position)

func load_area_from_file(area_file:PackedScene):
	# Checking the new scene path
	var full_path = area_file.get_path() as String
	var scene = load(full_path) as PackedScene
	scene = area_file
	if !scene:
		return
	current_area = 0
	current_area_path = scene
	# Remove previous scene
	for child in area_container.get_children():
		child.queue_free()
		await child.tree_exited
	# Setting up the new scene
	var instance = scene.instantiate()
	area_container.add_child(instance)
	#moving the player to the start position of the new scene
	var player_start_position = get_tree().get_first_node_in_group("player_start_position") as Node2D
	player.teleport_to_location(player_start_position.position)
	reset_energy_cells()

func load_area_from_file_with_startpos(area_file:PackedScene, start_pos_group:String):
	# Checking the new scene path
	var full_path = area_file.get_path() as String
	var scene = load(full_path) as PackedScene
	scene = area_file
	if !scene:
		return
	current_area = 0
	# Remove previous scene
	for child in area_container.get_children():
		child.queue_free()
		await child.tree_exited
	# Setting up the new scene
	var instance = scene.instantiate()
	area_container.add_child(instance)
	#moving the player to the start position of the new scene
	var player_start_position = get_tree().get_first_node_in_group(start_pos_group) as Node2D
	player.teleport_to_location(player_start_position.position)
	reset_energy_cells()

func add_energy_cell():
	energy_cells += 1
	hud.update_energy_cell_label(energy_cells)
	if energy_cells >= 4:
		var portal = get_tree().get_first_node_in_group("area_exits") as AreaExit
		portal.open()
		hud.portal_opened()
 
func reset_energy_cells():
	energy_cells = 0
	hud.update_energy_cell_label(energy_cells)
	hud.portal_closed()

 
func _on_restart_button_pressed():
	get_tree().reload_current_scene()

func set_pause(state:bool):
	scene_tree.set_pause(state)

func set_player_sprite(texture:Texture2D):
	player.set_sprite(texture)
