extends Sprite2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	if %AnimPlayer:
		%AnimPlayer.play("idle")


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if get_tree().get_first_node_in_group("player").get_position().x > get_global_position().x:
		set_flip_h(false)
	elif get_tree().get_first_node_in_group("player").get_position().x < get_global_position().x:
		set_flip_h(true)
