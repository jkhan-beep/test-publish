extends Area2D
class_name AreaExit

@export var sprite : Sprite2D
@export_category("Custom Load")
@export var custom_load : bool = true
@export var custom_load_target : PackedScene = preload("res://assets/scenes/level_select.tscn") as PackedScene
@export var start_open : bool = false
@export_category("Custom Start Position")
@export var custom_start_position : bool = false
@export var custom_load_target_group : String
var is_open = false
var hud : HUD
var menu : Menu
var player : PlayerController

func _ready():
	if start_open == false:
		close()
	else:
		is_open = true
		open()

func open():
	is_open = true
	sprite.region_rect.position.x = 22

func close():
	is_open = false
	sprite.region_rect.position.x = 0

func _on_body_entered(body):
	if is_open && body is PlayerController:
		if custom_load == false:
			GameManager.next_area()
		else:
			if custom_start_position == false:
				GameManager.load_area_from_file(custom_load_target)
			else:
				GameManager.load_area_from_file_with_startpos(custom_load_target, custom_load_target_group)
