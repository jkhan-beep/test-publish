extends Path2D
class_name Menu

@export var path_time = 1.0
@export var looping = false
@export var ease : Tween.EaseType
@export var transition : Tween.TransitionType
@export var path_follow_2D : PathFollow2D
@export var close_button_texture : NinePatchRect

var menu_open = false

func _input(event):
	# Handle jump.
	if event.is_action_pressed("menu"):
		if menu_open == false:
			menu_open = true
			open_menu()
		elif menu_open == true:
			menu_open = false
			close_menu()

func _on_close_button_pressed():
	close_menu()

func _on_mouse_entered():
	close_button_texture.region_rect.position.x = 5

func _on_mouse_exited():
	close_button_texture.region_rect.position.x = 0


func open_menu():
	var tween = get_tree().create_tween().set_loops()
	tween.tween_property(path_follow_2D, "progress_ratio", 1.0, path_time).set_ease(ease).set_trans(transition)
func close_menu():
	var tween = get_tree().create_tween().set_loops()
	tween.tween_property(path_follow_2D, "progress_ratio", 0.0, path_time).set_ease(ease).set_trans(transition)
