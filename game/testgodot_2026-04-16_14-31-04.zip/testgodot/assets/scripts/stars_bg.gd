extends Sprite2D
var offset_counter = 0
# Called when the node enters the scene tree for the first time.
func _ready():
	offset_counter = 0

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta):
	offset_counter = offset_counter + 0.001
	self.texture.noise.offset = Vector3(0, 0, offset_counter)
	#object.texture.noise.set_offset(Vector3(offset_counter,0,0))
