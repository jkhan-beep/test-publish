extends Area2D
class_name EnterArea

@export var area_number : int
@export var text : TextMesh

func _ready():
	text.set_text("Area "+ area_number)

func _on_body_entered(body):
	if body is LevelSelectPlayerController:
		get_tree().change_scene_to_file("res://assets/scenes/gameplay.tscn")
		GameManager.load_area(1)
