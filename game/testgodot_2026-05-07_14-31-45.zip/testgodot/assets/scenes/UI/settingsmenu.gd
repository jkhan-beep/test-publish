extends Path2D

@export var path_time = 1.0
@export var looping = false
@export var ease : Tween.EaseType
@export var transition : Tween.TransitionType
@export var tab_bar : TabContainer
@export var tabs_path_2D : Path2D
@export var tabs_path_follow_2D : PathFollow2D
@export var controller_texture_label : Label
var tab_number = 0
# Called when the node enters the scene tree for the first time.
func _ready():
	pass # Replace with function body.
	controller_texture_label.text = "Controller Texture: Generic"


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta):
	pass

func _on_fullscreen_toggled(toggled_on):
	if toggled_on == true:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)


func _on_settings_tab_changed(tab):
	tab_number = tab
	var tween = tabs_path_2D.get_tree().create_tween().set_loops()
	tween.tween_property(tabs_path_follow_2D, "progress_ratio", tab, path_time).set_ease(ease).set_trans(transition)

func _input(event):
	# Handle jump.
	if event.is_action_pressed("menu"):
		var tween = tabs_path_2D.get_tree().create_tween().set_loops()
		tween.tween_property(tabs_path_follow_2D, "progress_ratio", 0, path_time).set_ease(ease).set_trans(transition)
		tab_bar.set_current_tab(0)


func _on_controller_texture_value_changed(value):
	if value == 0:
		GameManager.controllertexture = load("res://assets/sprites/controls/generic.png")
		controller_texture_label.text = "Controller Texture: Generic"
	if value == 1:
		GameManager.controllertexture = load("res://assets/sprites/controls/xbox.png")
		controller_texture_label.text = "Controller Texture: Xbox"
	if value == 2:
		GameManager.controllertexture = load("res://assets/sprites/controls/ps.png")
		controller_texture_label.text = "Controller Texture: PS"
	if value == 3:
		GameManager.controllertexture = load("res://assets/sprites/controls/switch.png")
		controller_texture_label.text = "Controller Texture: Switch"
	if value > 3:
		GameManager.controllertexture = load("res://assets/sprites/controls/generic.png")
		controller_texture_label.text = "Controller Texture: ???"
	for i in get_tree().get_nodes_in_group("controller_texture"):
		i.texture = GameManager.controllertexture


func _on_focus_toggled(toggled_on):
	GameManager.focus_ui = toggled_on
	if GameManager.focus_ui == true:
		for i in get_tree().get_nodes_in_group("focusable"):
			i.set_focus_mode(2)
	else:
		for i in get_tree().get_nodes_in_group("focusable"):
			i.set_focus_mode(0)
