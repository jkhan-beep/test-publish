extends CharacterBody3D
class_name Player3D

@export var speed = 5.0
@export var jump_power = 5.0

@export var sprite : Sprite3D
@export var up_texture : CompressedTexture2D
@export var down_texture : CompressedTexture2D
@export var left_texture : CompressedTexture2D
@export var right_texture : CompressedTexture2D
@export var animation_player : AnimationPlayer
var running = false
var speed_multiplier = 15.0*0.0625
var jump_multiplier = 30.0*0.0625
var menu : Menu
@export var in_water = false
# Get the gravity from the project settings to be synced with RigidBody nodes.
var gravity = ProjectSettings.get_setting("physics/3d/default_gravity")

func _ready():
	menu.set_restart_disabled(true)

func _input(event):
	# Handle jump.
	if event.is_action_pressed("jump") and is_on_floor() or event.is_action_pressed("jump") and in_water:
		velocity.y = jump_power * jump_multiplier
	# Handle jump down
#	if event.is_action_pressed("move_down"):
#		set_collision_mask_value(10, false)
#	else:
#		set_collision_mask_value(10, true)
	if Input.is_action_pressed("run"):
		running = true
		speed_multiplier = 30.0*0.0625
	else:
		running = false
		speed_multiplier = 15.0*0.0625

func _physics_process(delta):
	# Add the gravity.
	if not is_on_floor():
		velocity.y -= (gravity * delta)*2

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var input_dir = Input.get_vector("move_left", "move_right", "move_up", "move_down")
	var direction = (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	if direction:
		velocity.x = direction.x * (speed * speed_multiplier)
		velocity.z = direction.z * (speed * speed_multiplier)
	else:
		velocity.x = move_toward(velocity.x, 0, (speed * speed_multiplier))
		velocity.z = move_toward(velocity.z, 0, (speed * speed_multiplier))
	# texture
	if direction.x > 0:
		sprite.texture = right_texture
	if direction.x < 0:
		sprite.texture = left_texture
	if direction.z > 0 and direction.x == 0:
		sprite.texture = down_texture
	if direction.z < 0 and direction.x == 0:
		sprite.texture = up_texture
	if direction != Vector3(0,0,0) and velocity != Vector3(0,0,0) :
		animation_player.play("move")
	else:
		animation_player.play("idle")
	#plays the jump animation
	if velocity.y > 0.0:
		animation_player.play("jump")
	if velocity.y < 0.0:
		animation_player.play("fall")

	move_and_slide()
